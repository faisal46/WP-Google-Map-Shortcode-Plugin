<?php
/*
Plugin Name: Google Map ShortCode
Plugin URI: https://github.com/faisal46/WP-Google-Map-Shortcode-Plugin
Description: This is the WordPress shortcode generate.
Version: 1.0
Author: RajTech
Author URI: www.faisal.rajtechbd.com
License: GPLv2 or later
Text Domain: rtechsc
Domain Path: /langusges/
*/

function rtechsc_load_text_domain(){
    load_textdomain('rtechsc', false, dirname(__FILE__) . "/languages");
}
add_action('plugins_loaded', 'rtechsc_load_text_domain');

function rtechsc_button( $attributes ){
    $default = array(
        'type' => 'primary',
        'url' => '',
        'title' => __("Button", 'rtechsc'),
    );
    $button_attributes = shortcode_atts( $default,$attributes );

 return sprintf('<a target="_blank" class="btn btn-%s" href="%s">%s</a>',
     $button_attributes['type'],
     $button_attributes['url'],
     $button_attributes['title']
 );
}
add_shortcode('button', 'rtechsc_button');

function rtechsc_button2( $attributes, $content='' ){
    $default = array(
        'type' => 'primary',
        'url' => '',
    );
    $button_attributes = shortcode_atts( $default,$attributes );
 return sprintf('<a target="_blank" class="btn btn-%s" href="%s">%s</a>',
     $button_attributes['type'],
     $button_attributes['url'],
     do_shortcode($content)
 );
}
add_shortcode('button2', 'rtechsc_button2');

function rtechsc_uppercase($attributes, $content=''){
    return strtoupper(do_shortcode($content));
}
add_shortcode('uc', 'rtechsc_uppercase');

function rtechsc_google_map($attributes){
    $default = array(
        'place' => 'Dhaka',
        'width' => '600',
        'height' => '500',
        'zoom' => '13',
    );
    $params = shortcode_atts($default,$attributes);
    $map = <<<EOD
<div class="mapouter"><div class="gmap_canvas"><iframe width="{$params['width']}" height="{$params['height']}" id="gmap_canvas" src="https://maps.google.com/maps?q={$params['place']}&t=&z={$params['zoom']}&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a><br><style>.mapouter{position:relative;text-align:right;height:500px;width:600px;}</style><a href="https://www.embedgooglemap.net">create google map for website</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:600px;}</style></div></div>
EOD;
    return $map;
}
add_shortcode('gmap', 'rtechsc_google_map');
